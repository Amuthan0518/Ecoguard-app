EcoGuard Dark Theme update

1. Make a backup copy of your current app.py first.
2. Replace your project's app.py with this updated app.py.
3. Keep requirements.txt and ecoguard.db in your original project folder.
4. In the VS Code terminal, stop the old app with Ctrl+C if it is running.
5. Run: python -m streamlit run app.py
6. Refresh http://localhost:8501 in your browser.

This is a visual theme update. It does not add real AI, cloud hosting, or user accounts yet.
